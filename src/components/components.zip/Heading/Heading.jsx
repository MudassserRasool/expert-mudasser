import React from 'react'
import Style from './Heading.module.css'

const Heading = () => {
  return (
    <div>
        <h1 className={Style.mannageBussinessesHeading}>Manage Businesses</h1>
    </div>
  )
}

export default Heading