import React from "react";
import "./Form.css";

const Form = () => {
  return (
    <div>
      <div className="conatiner m-2">
        <div className="row mx-4">
          <table>
            <thead className="formTableHeaderBorder">
              <tr className="formHeadingRow">
                <th className="text-start formTableTextgRow formLogoCoustomWidth">Logo</th>
                <th className="text-start formTableTextgRow formBusinessNameCoustomWidth">Business Name</th>
                <th className="formTableTextgRow formDesignationCoustomWidth">Designation</th>
                <th className="text-start formTableTextgRow formAdressCoustomWidth" >
                  Business Address
                </th>
                <th className="text-start formTableTextgRow formStatusCoustomWidth">Status</th>
                <th className="text-end formTableTextgRow formActionsCoustomWidth">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="formTableBodyBorder">
                <td className="text-start">
                  <div>Image</div>
                </td>
                <td className="text-start">Fauji Cereals</td>
                <td className="text-start">Admin</td>
                <td className="text-start">
                  Hall, Cove Road Malham Yorkshire, United Kingdom (BD23 4DJ)
                </td>
                <td className="text-start">Active</td>
                <td className="text-end">
                  <div className="d-flex justify-content-end gap-2">
                    <div>
                      <a href="">Link</a>
                    </div>
                    <div>edit</div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Form;
