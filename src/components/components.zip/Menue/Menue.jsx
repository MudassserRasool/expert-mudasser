import React from "react";
import Style from "./Menue.module.css";
import HomeImage from "..//../assets/HomeIcon.png";
import ProfileImage from "..//../assets/img.jpeg";

const Menue = () => {
  return (
    <div className={Style.flexContainer}>
      {/* Start Left side */}
      <div className={Style.leftSide}>
        <span className="">
          <img
            src={HomeImage}
            alt="Home icon not loaded"
            className={` ${Style.smallIconHome}`}
          />
          <a href="/" className={Style.underline}>
            Main Task
          </a>
        </span>
        <span className={Style.underlineItemsTwo}>
          <a href="/" className={Style.underline}>
            Timeline
          </a>
        </span>
        <span className={Style.underlineItemsThree}>
          <a href="/" className={Style.underline}>
            Services
          </a>
        </span>
      </div>
      {/* End Left side */}

      {/* Start Right side */}
      <div className={Style.rightSide}>
        <span className={Style.activityAndImage}>
          <a href="/" className={Style.activity}>
            Activity
          </a>
          <img
            src={ProfileImage}
            alt="Home icon not loaded"
            className={` ${Style.ProfileImage}`}
            width={21}
            height={21}
          />
        </span>

        {/* Start Button and icon */}
        <span className={Style.underlineItemsTwo}>
          <button className={Style.iconButton}>
            <img
              src={ProfileImage}
              alt="Home icon not loaded"
              className={` ${Style.ProfileImage}`}
              width={21}
              height={21}
            />
            <span className={Style.likeText}>Invite / 5</span>
          </button>
        </span>
        {/* End Button and icon */}

        <span>
          <a href="/" className={Style.threeDots}>
            ...
          </a>
        </span>
      </div>
      {/* End Right side */}
    </div>
  );
};

export default Menue;
