import React, { useState, useRef, useEffect } from "react";
import Style from "./Menues.module.css";
import HomeImage from "..//../assets/HomeIcon.png";
import AddTaskIcon from "..//../assets/AddTaskIcon.png";

const Menues = () => {
  const [activeItem, setActiveItem] = useState("mainTask");
  const underlineRef = useRef(null);

  const handleItemClick = (item) => {
    setActiveItem(item);
  };

  useEffect(() => {
    const activeNavItem = document.querySelector(`.${Style.activeNavItem}`);
    if (activeNavItem && underlineRef.current) {
      underlineRef.current.style.left = `${activeNavItem.offsetLeft}px`;
      underlineRef.current.style.width = `${activeNavItem.offsetWidth}px`;
    }
  }, [activeItem]);

  return (
    <div className={Style.container}>
      <div className={`${Style.flexContainer} ${Style.justifyBetween}`}>
        {/* Start Left side items */}
        <div className={`${Style.flexColumn} ${Style.colMd4}`}>
          <div
            className={`${Style.flexContainer} ${Style.justifyBetween} ${Style.gap2}`}
          >
            {/* First Item Image and text */}
            <div className={Style.flexColumn}>
              <div
                className={`${Style.flexContainer} ${Style.gap1} ${Style.alignCenter}`}
              >
                <img
                  src={HomeImage}
                  alt="Home icon not loaded"
                  className={`${Style.imgFluid} ${Style.smallIconHome}`}
                />
                <p
                  className={`${Style.mainTaskText} ${
                    activeItem === "mainTask" ? Style.activeNavItem : ""
                  }`}
                  onClick={() => handleItemClick("mainTask")}
                >
                  Main Task
                </p>
              </div>
            </div>

            <p
              className={`${Style.timelineText} ${
                activeItem === "timeline" ? Style.activeNavItem : ""
              }`}
              onClick={() => handleItemClick("timeline")}
            >
              Timeline
            </p>
            <p
              className={`${Style.servicesText} ${
                activeItem === "services" ? Style.activeNavItem : ""
              }`}
              onClick={() => handleItemClick("services")}
            >
              Services
            </p>
            <div className="">
              <img
                src={AddTaskIcon}
                alt="Icon to assign task is not loaded"
                className={`${Style.smallIcon} ${Style.smallIconOrder}`}
              />
            </div>
          </div>
          <div
            className={Style.underline}
            ref={underlineRef}
          ></div>
        </div>
        {/* End Left side items */}
        
        
      </div>
    </div>
  );
};

export default Menues;
