import React from "react";
import "./ReuseableButton.css";

const ReuseableButton = ({status}) => {
  return (
    <div>
      {status === "1" ? <div className="buttonStyleAvtiveBox">
        <p className="buttonStyleAvtiveText">Active</p>
      </div> : status === "2" ? <div className="buttonStyleSuspendedBox">
        <p className="buttonStyleSuspendedText">Suspended</p>
      </div> : status === "3" ? <div className="buttonStylePendingBox">
        <p className="buttonStylePendingText">Pending</p>
      </div> : null}

    </div>
  );
};

export default ReuseableButton;
