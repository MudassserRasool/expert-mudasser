import React from 'react'
import Style from './ReuseableText.module.css'

const ReuseableText = () => {
  return (
    <div>
        <h1 className={Style.designTeamText}>Design Team</h1>
    </div>
  )
}

export default ReuseableText